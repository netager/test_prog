# JB-KMS 설치 및 실행 가이드

## 1. 설치 방법

### 1.1 패키지 설치
```bash
# 패키지 설치 스크립트 실행
./setup/install_packages.sh
```

### 1.2 데이터베이스 초기화
```bash
# 가상환경 활성화
source venv/bin/activate

# 데이터베이스 초기화
flask db upgrade
python init_db.py

# 가상환경 비활성화
deactivate
```

### 1.3 환경 설정
.env 파일의 설정을 환경에 맞게 수정하세요:
- GUNICORN_PORT: 서버 포트 번호
- GUNICORN_WORKERS: 워커 프로세스 수 (CPU 코어 수 * 2 + 1 권장)
- GUNICORN_THREADS: 스레드 수 (2~4개 권장)
- GUNICORN_TIMEOUT: 타임아웃 설정

## 2. 서버 실행
```bash
# 서버 실행 스크립트 실행
./bin/start_server.sh
```

## 3. 로그 확인
- 접근 로그: logs/access.log
- 에러 로그: logs/error.log

## 4. 서버 중지
```bash
pkill -f gunicorn
```
